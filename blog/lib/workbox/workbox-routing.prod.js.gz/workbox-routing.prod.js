this.workbox=this.workbox||{},this.workbox.routing=function(t,e){"use strict"
try{self["workbox:routing:7.0.0"]&&_()}catch(t){}const r=t=>t&&"object"==typeof t?t:{handle:t}
class s{constructor(t,e,s="GET"){this.handler=r(e),this.match=t,this.method=s}setCatchHandler(t){this.catchHandler=r(t)}}class n extends s{constructor(t,e,r){super((({url:e})=>{const r=t.exec(e.href)
if(r&&(e.origin===location.origin||0===r.index))return r.slice(1)}),e,r)}}class o{constructor(){this.ft=new Map,this.dt=new Map}get routes(){return this.ft}addFetchListener(){self.addEventListener("fetch",(t=>{const{request:e}=t,r=this.handleRequest({request:e,event:t})
r&&t.respondWith(r)}))}addCacheListener(){self.addEventListener("message",(t=>{if(t.data&&"CACHE_URLS"===t.data.type){const{payload:e}=t.data,r=Promise.all(e.urlsToCache.map((e=>{"string"==typeof e&&(e=[e])
const r=new Request(...e)
return this.handleRequest({request:r,event:t})})))
t.waitUntil(r),t.ports&&t.ports[0]&&r.then((()=>t.ports[0].postMessage(!0)))}}))}handleRequest({request:t,event:e}){const r=new URL(t.url,location.href)
if(!r.protocol.startsWith("http"))return
const s=r.origin===location.origin,{params:n,route:o}=this.findMatchingRoute({event:e,request:t,sameOrigin:s,url:r})
let i=o&&o.handler
const a=t.method
if(!i&&this.dt.has(a)&&(i=this.dt.get(a)),!i)return
let h
try{h=i.handle({url:r,request:t,event:e,params:n})}catch(t){h=Promise.reject(t)}const u=o&&o.catchHandler
return h instanceof Promise&&(this.wt||u)&&(h=h.catch((async s=>{if(u)try{return await u.handle({url:r,request:t,event:e,params:n})}catch(t){t instanceof Error&&(s=t)}if(this.wt)return this.wt.handle({url:r,request:t,event:e})
throw s}))),h}findMatchingRoute({url:t,sameOrigin:e,request:r,event:s}){const n=this.ft.get(r.method)||[]
for(const o of n){let n
const i=o.match({url:t,sameOrigin:e,request:r,event:s})
if(i)return n=i,(Array.isArray(n)&&0===n.length||i.constructor===Object&&0===Object.keys(i).length||"boolean"==typeof i)&&(n=void 0),{route:o,params:n}}return{}}setDefaultHandler(t,e="GET"){this.dt.set(e,r(t))}setCatchHandler(t){this.wt=r(t)}registerRoute(t){this.ft.has(t.method)||this.ft.set(t.method,[]),this.ft.get(t.method).push(t)}unregisterRoute(t){if(!this.ft.has(t.method))throw new e.WorkboxError("unregister-route-but-not-found-with-method",{method:t.method})
const r=this.ft.get(t.method).indexOf(t)
if(!(r>-1))throw new e.WorkboxError("unregister-route-route-not-registered")
this.ft.get(t.method).splice(r,1)}}let i
const a=()=>(i||(i=new o,i.addFetchListener(),i.addCacheListener()),i)
return t.NavigationRoute=class extends s{constructor(t,{allowlist:e=[/./],denylist:r=[]}={}){super((t=>this.gt(t)),t),this.qt=e,this.yt=r}gt({url:t,request:e}){if(e&&"navigate"!==e.mode)return!1
const r=t.pathname+t.search
for(const t of this.yt)if(t.test(r))return!1
return!!this.qt.some((t=>t.test(r)))}},t.RegExpRoute=n,t.Route=s,t.Router=o,t.registerRoute=function(t,r,o){let i
if("string"==typeof t){const e=new URL(t,location.href)
i=new s((({url:t})=>t.href===e.href),r,o)}else if(t instanceof RegExp)i=new n(t,r,o)
else if("function"==typeof t)i=new s(t,r,o)
else{if(!(t instanceof s))throw new e.WorkboxError("unsupported-route-type",{moduleName:"workbox-routing",funcName:"registerRoute",paramName:"capture"})
i=t}return a().registerRoute(i),i},t.setCatchHandler=function(t){a().setCatchHandler(t)},t.setDefaultHandler=function(t){a().setDefaultHandler(t)},t}({},workbox.core._private)
