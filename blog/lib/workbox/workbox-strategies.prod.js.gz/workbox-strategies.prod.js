this.workbox=this.workbox||{},this.workbox.strategies=function(t,e,r,s,a,n,o,i,c){"use strict"
function h(t){return"string"==typeof t?new Request(t):t}try{self["workbox:strategies:7.0.0"]&&_()}catch(t){}class l{constructor(t,e){this.vt={},Object.assign(this,e),this.event=e.event,this.ht=t,this.bt=new a.Deferred,this.Et=[],this._t=[...t.plugins],this.kt=new Map
for(const t of this._t)this.kt.set(t,{})
this.event.waitUntil(this.bt.promise)}async fetch(t){const{event:r}=this
let s=h(t)
if("navigate"===s.mode&&r instanceof FetchEvent&&r.preloadResponse){const t=await r.preloadResponse
if(t)return t}const a=this.hasCallback("fetchDidFail")?s.clone():null
try{for(const t of this.iterateCallbacks("requestWillFetch"))s=await t({request:s.clone(),event:r})}catch(t){if(t instanceof Error)throw new e.WorkboxError("plugin-error-request-will-fetch",{thrownErrorMessage:t.message})}const n=s.clone()
try{let t
t=await fetch(s,"navigate"===s.mode?void 0:this.ht.fetchOptions)
for(const e of this.iterateCallbacks("fetchDidSucceed"))t=await e({event:r,request:n,response:t})
return t}catch(t){throw a&&await this.runCallbacks("fetchDidFail",{error:t,event:r,originalRequest:a.clone(),request:n.clone()}),t}}async fetchAndCachePut(t){const e=await this.fetch(t),r=e.clone()
return this.waitUntil(this.cachePut(t,r)),e}async cacheMatch(t){const e=h(t)
let r
const{cacheName:s,matchOptions:a}=this.ht,n=await this.getCacheKey(e,"read"),o=Object.assign(Object.assign({},a),{cacheName:s})
r=await caches.match(n,o)
for(const t of this.iterateCallbacks("cachedResponseWillBeUsed"))r=await t({cacheName:s,matchOptions:a,cachedResponse:r,request:n,event:this.event})||void 0
return r}async cachePut(t,r){const a=h(t)
await c.timeout(0)
const i=await this.getCacheKey(a,"write")
if(!r)throw new e.WorkboxError("cache-put-with-no-response",{url:o.getFriendlyURL(i.url)})
const l=await this.xt(r)
if(!l)return!1
const{cacheName:u,matchOptions:w}=this.ht,f=await self.caches.open(u),p=this.hasCallback("cacheDidUpdate"),d=p?await s.cacheMatchIgnoreParams(f,i.clone(),["__WB_REVISION__"],w):null
try{await f.put(i,p?l.clone():l)}catch(t){if(t instanceof Error)throw"QuotaExceededError"===t.name&&await n.executeQuotaErrorCallbacks(),t}for(const t of this.iterateCallbacks("cacheDidUpdate"))await t({cacheName:u,oldResponse:d,newResponse:l.clone(),request:i,event:this.event})
return!0}async getCacheKey(t,e){const r=`${t.url} | ${e}`
if(!this.vt[r]){let s=t
for(const t of this.iterateCallbacks("cacheKeyWillBeUsed"))s=h(await t({mode:e,request:s,event:this.event,params:this.params}))
this.vt[r]=s}return this.vt[r]}hasCallback(t){for(const e of this.ht.plugins)if(t in e)return!0
return!1}async runCallbacks(t,e){for(const r of this.iterateCallbacks(t))await r(e)}*iterateCallbacks(t){for(const e of this.ht.plugins)if("function"==typeof e[t]){const r=this.kt.get(e),s=s=>{const a=Object.assign(Object.assign({},s),{state:r})
return e[t](a)}
yield s}}waitUntil(t){return this.Et.push(t),t}async doneWaiting(){let t
for(;t=this.Et.shift();)await t}destroy(){this.bt.resolve(null)}async xt(t){let e=t,r=!1
for(const t of this.iterateCallbacks("cacheWillUpdate"))if(e=await t({request:this.request,response:e,event:this.event})||void 0,r=!0,!e)break
return r||e&&200!==e.status&&(e=void 0),e}}class u{constructor(t={}){this.cacheName=r.cacheNames.getRuntimeName(t.cacheName),this.plugins=t.plugins||[],this.fetchOptions=t.fetchOptions,this.matchOptions=t.matchOptions}handle(t){const[e]=this.handleAll(t)
return e}handleAll(t){t instanceof FetchEvent&&(t={event:t,request:t.request})
const e=t.event,r="string"==typeof t.request?new Request(t.request):t.request,s="params"in t?t.params:void 0,a=new l(this,{event:e,request:r,params:s}),n=this.Rt(a,r,e)
return[n,this.Wt(n,a,r,e)]}async Rt(t,r,s){let a
await t.runCallbacks("handlerWillStart",{event:s,request:r})
try{if(a=await this._handle(r,t),!a||"error"===a.type)throw new e.WorkboxError("no-response",{url:r.url})}catch(e){if(e instanceof Error)for(const n of t.iterateCallbacks("handlerDidError"))if(a=await n({error:e,event:s,request:r}),a)break
if(!a)throw e}for(const e of t.iterateCallbacks("handlerWillRespond"))a=await e({event:s,request:r,response:a})
return a}async Wt(t,e,r,s){let a,n
try{a=await t}catch(n){}try{await e.runCallbacks("handlerDidRespond",{event:s,request:r,response:a}),await e.doneWaiting()}catch(t){t instanceof Error&&(n=t)}if(await e.runCallbacks("handlerDidComplete",{event:s,request:r,response:a,error:n}),e.destroy(),n)throw n}}const w={cacheWillUpdate:async({response:t})=>200===t.status||0===t.status?t:null}
return t.CacheFirst=class extends u{async _handle(t,r){let s,a=await r.cacheMatch(t)
if(!a)try{a=await r.fetchAndCachePut(t)}catch(t){t instanceof Error&&(s=t)}if(!a)throw new e.WorkboxError("no-response",{url:t.url,error:s})
return a}},t.CacheOnly=class extends u{async _handle(t,r){const s=await r.cacheMatch(t)
if(!s)throw new e.WorkboxError("no-response",{url:t.url})
return s}},t.NetworkFirst=class extends u{constructor(t={}){super(t),this.plugins.some((t=>"cacheWillUpdate"in t))||this.plugins.unshift(w),this.Ot=t.networkTimeoutSeconds||0}async _handle(t,r){const s=[],a=[]
let n
if(this.Ot){const{id:e,promise:o}=this.Ut({request:t,logs:s,handler:r})
n=e,a.push(o)}const o=this.Ct({timeoutId:n,request:t,logs:s,handler:r})
a.push(o)
const i=await r.waitUntil((async()=>await r.waitUntil(Promise.race(a))||await o)())
if(!i)throw new e.WorkboxError("no-response",{url:t.url})
return i}Ut({request:t,logs:e,handler:r}){let s
return{promise:new Promise((e=>{s=setTimeout((async()=>{e(await r.cacheMatch(t))}),1e3*this.Ot)})),id:s}}async Ct({timeoutId:t,request:e,logs:r,handler:s}){let a,n
try{n=await s.fetchAndCachePut(e)}catch(t){t instanceof Error&&(a=t)}return t&&clearTimeout(t),!a&&n||(n=await s.cacheMatch(e)),n}},t.NetworkOnly=class extends u{constructor(t={}){super(t),this.Ot=t.networkTimeoutSeconds||0}async _handle(t,r){let s,a
try{const e=[r.fetch(t)]
if(this.Ot){const t=c.timeout(1e3*this.Ot)
e.push(t)}if(a=await Promise.race(e),!a)throw new Error(`Timed out the network response after ${this.Ot} seconds.`)}catch(t){t instanceof Error&&(s=t)}if(!a)throw new e.WorkboxError("no-response",{url:t.url,error:s})
return a}},t.StaleWhileRevalidate=class extends u{constructor(t={}){super(t),this.plugins.some((t=>"cacheWillUpdate"in t))||this.plugins.unshift(w)}async _handle(t,r){const s=r.fetchAndCachePut(t).catch((()=>{}))
r.waitUntil(s)
let a,n=await r.cacheMatch(t)
if(n);else try{n=await s}catch(t){t instanceof Error&&(a=t)}if(!n)throw new e.WorkboxError("no-response",{url:t.url,error:a})
return n}},t.Strategy=u,t.StrategyHandler=l,t}({},workbox.core._private,workbox.core._private,workbox.core._private,workbox.core._private,workbox.core._private,workbox.core._private,workbox.core._private,workbox.core._private)
